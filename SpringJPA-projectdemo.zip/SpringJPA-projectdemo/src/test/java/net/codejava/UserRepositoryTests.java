@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
public class UserRepositoryTests {

    @Autowired
    private TestEntityManager entityManager;

    @Autowired
    private UserRepository userRepository;

    @Test
    public void testFindUserByEmail() {
        // Given
        User user = new User();
        user.setEmail("ravikumar@gmail.com");
        user.setPassword("ravi2020"); // Ensure correct method name 'setPassword'
        user.setFirstname("Ravi");
        user.setLastname("Kumar");

        // When
        User savedUser = entityManager.persistFlushFind(user);

        // Then
        User foundUser = userRepository.findByEmail("ravikumar@gmail.com");
        assertThat(foundUser.getEmail()).isEqualTo(savedUser.getEmail());
    }

    // Add more test cases as needed for UserRepository methods
}
